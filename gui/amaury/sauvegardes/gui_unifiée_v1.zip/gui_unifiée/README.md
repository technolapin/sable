# GUI

## Utilisation
Exécuter `main.py` pour avoir toutes les fonctionnalités.

Exécuter `class_Fenetre.py` pour avoir l'environnement de démonstration uniquement.

Exécutr une `class_Tab*.py` pour avoir les onglets séparemments.
