"""
PARAMETRES
"""
# Désactive la vue IRM, qui est buggée
# Utilisé par class_Fenetre.py et class_TabAide.py
DISABLE_IRM = True

# Désactive l'affichache multi-couches dans le mille-feuilles
# Utlisé par class_TabMilleFeuille3D.py
ENABLE_ANTI_LAG = True