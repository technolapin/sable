# GUI

## Utilisation
Exécuter `python3 main.py` pour avoir toutes les fonctionnalités.

Exécuter `python3 class_Fenetre.py` pour avoir l'environnement de démonstration uniquement.

Exécutr une `python3 class_Tab*.py` pour avoir les onglets séparemments.
